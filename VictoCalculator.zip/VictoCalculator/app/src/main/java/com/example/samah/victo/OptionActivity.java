package com.example.samah.victo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.samah.victo.Product.ProductActivity;
import com.example.samah.victo.Raw.RawActivity;


public class OptionActivity extends AppCompatActivity {
    boolean clicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);



    }

    @Override
    protected void onResume() {
        super.onResume();
        clicked =false;
    }

    public void OnClick(View view) {
        if(clicked) return;
        clicked = true;
        //Flash, Pulse, RubberBand, Shake, Swing, Wobble, Bounce, Tada, StandUp, Wave
        YoYo.with(Techniques.Pulse).duration(150).playOn(view);
        Class<?> aClass = null;


        if (view.equals(findViewById(R.id.calButton))) aClass = CalculatorActivity.class;
        else if (view.equals(findViewById(R.id.proButton))) aClass = ProductActivity.class;
        else if (view.equals(findViewById(R.id.rawButton))) aClass = RawActivity.class;

        Class<?> finalAClass = aClass;

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(this, finalAClass);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }, 150);




    }




}


